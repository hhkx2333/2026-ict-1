# 2026-ict-1
华为 ICT 大赛创新赛三人团队项目

## B 组评分核心与校准评测

输入题目、固定版本评分细则与单份文本答案，返回逐项建议分、原文证据与复核原因；支持审核案例检索、校准草案、受限复核、练习筛选、四种评分路径及独立评测。只使用 Python 3.10+ 标准库。

```sh
python3 -m examples.demo
python3 -m examples.calibration_demo
python3 -m unittest discover -s tests -v
```

[最新接口、数据检查、运行方法与待办](docs/b-handoff.md)。离线演示回放合成数据，不代表真实模型评分效果；正式成绩须经教师确认。本轮未接入真实模型、未取得教师对评分草案的审核。
