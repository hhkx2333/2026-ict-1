"""Explicit providers: offline fixtures and opt-in compatible chat-completions API."""
import json
import os
from urllib.parse import urlparse
from urllib.request import Request, build_opener, HTTPRedirectHandler


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError('model endpoint redirects are not allowed')


def urlopen(request, timeout):
    # Do not forward a Bearer key to a redirected destination.
    return build_opener(_NoRedirect()).open(request, timeout=timeout)


class FixtureProvider:
    """Replays a fixed model output; does NOT evaluate answer semantics."""
    model = 'fixture-replay-not-a-real-model'

    def __init__(self, output):
        self.output = json.dumps(output, ensure_ascii=False, allow_nan=False)

    def complete(self, system, payload):
        return self.output


class ChatCompletionsProvider:
    """Use only after verifying the model service supports this protocol.

    endpoint is a full HTTPS /chat/completions URL; no provider is auto-selected.
    No streaming, tools, hidden retries, or service-specific authentication.
    """
    def __init__(self, endpoint, model, api_key, timeout=30):
        parsed = urlparse(endpoint)
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError('endpoint must be HTTPS without embedded credentials')
        if not model or not api_key or not 0 < timeout <= 120:
            raise ValueError('model, API key and timeout (0,120] are required')
        self.endpoint, self.model, self.api_key, self.timeout = endpoint, model, api_key, timeout

    @classmethod
    def from_env(cls):
        return cls(os.environ['GRADING_ENDPOINT'], os.environ['GRADING_MODEL'], os.environ['GRADING_API_KEY'])

    def complete(self, system, payload):
        body = {'model': self.model, 'temperature': 0,
                'messages': [{'role': 'system', 'content': system},
                             {'role': 'user', 'content': json.dumps(payload, ensure_ascii=False)}],
                'response_format': {'type': 'json_object'}, 'max_tokens': 4096}
        request = Request(self.endpoint, data=json.dumps(body).encode(), method='POST',
                          headers={'Authorization': 'Bearer ' + self.api_key,
                                   'Content-Type': 'application/json'})
        with urlopen(request, timeout=self.timeout) as response:
            raw = response.read(1_000_001)
        if len(raw) > 1_000_000:
            raise ValueError('model response too large')
        return json.loads(raw)['choices'][0]['message']['content']
