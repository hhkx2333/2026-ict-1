"""Backend components shared with the application integration layer."""
