"""Explicitly synthetic, offline grading examples."""
